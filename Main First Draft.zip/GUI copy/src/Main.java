import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main implements ActionListener{
	private static JPasswordField passwordtxt;
	private static JTextField usertxt;
	private static JLabel userLabel;
	private static JLabel pwLabel;
	private static JButton loginButton;
	private static JLabel success;
	private static JLabel image;
	private static JFrame frame;

	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {

			public void run() {
				try {

					// initializing frame size
					final int HEIGHT = 800;
					final int WIDTH = 1400;
					frame = new JFrame("Tackle - Lucia Kim, Frances Zhao");
					frame.setSize(WIDTH,HEIGHT);
					frame.setVisible(true);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setBackground(new Color(243, 215, 3));
					frame.getContentPane().setBackground(new Color(243, 215, 3));
					frame.getContentPane().setLayout(null);

					// initializing label as the Tackle logo image
					image = new JLabel("Tackle Logo Image");
					image.setBounds(457, 107, 466, 160);
					frame.getContentPane().add(image);
					image.setIcon(new ImageIcon("images/logo.png"));

					// initializing user text field
					usertxt = new JTextField(10);
					usertxt.setColumns(10);
					usertxt.setBounds(639, 279, 175, 26);
					frame.getContentPane().add(usertxt);

					// initializing password field
					passwordtxt = new JPasswordField();
					passwordtxt.setColumns(10);
					passwordtxt.setBounds(639, 317, 175, 26);
					frame.getContentPane().add(passwordtxt);

					// initializing user label
					userLabel = new JLabel("user: ");
					userLabel.setBounds(592, 284, 35, 16);
					frame.getContentPane().add(userLabel);

					// initializing password label
					pwLabel = new JLabel("password: ");
					pwLabel.setBounds(559, 322, 68, 16);
					frame.getContentPane().add(pwLabel);

					// initializing a login button
					loginButton = new JButton("Login");
					loginButton.setBounds(642, 359, 117, 29);
					loginButton.addActionListener(new test()); // adding actionListener for login success
					frame.getContentPane().add(loginButton);

					// initializing success – will be removed after create account class is created
					success = new JLabel("");
					success.setHorizontalAlignment(SwingConstants.CENTER);
					success.setBounds(574, 400, 240, 16);
					frame.getContentPane().add(success);


				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/*
	 * currently, without the create account method, the login doesn't fully work yet
	 * once Create Account class created, the if statement will be changed to match the new account
	 * somehow, this does not work 
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String user = usertxt.getText();
		String password = passwordtxt.getText();
		System.out.println(user + ", " + password);

		if (user.equals(usertxt.getText()) && password.equals(passwordtxt.getText())) {
			success.setText("login successful!");
		}
		else {
			success.setText("username or password invalid");
		}
	}
}